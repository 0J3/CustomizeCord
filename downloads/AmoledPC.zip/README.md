# AmoledPC

AmoledBD but for PowerCord
